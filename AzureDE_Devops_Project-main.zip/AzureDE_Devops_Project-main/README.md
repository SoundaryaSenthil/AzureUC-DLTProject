# AzureDE-Devops_Project
Azure Data Engineering project with CI/CD and have created Delta live tables in the gold layer
